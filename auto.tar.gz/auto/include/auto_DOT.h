#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h> 

#include "auto.h"
#include "auto_file.h"

#ifndef _AUTO_DOT_H

#define _AUTO_DOT_H 1

void DOTaut(aut_t *paut) ;

#endif
