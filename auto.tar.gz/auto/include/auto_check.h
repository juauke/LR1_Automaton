#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h> 

#include "auto.h"

#ifndef _AUTO_CHECK_H

#define _AUTO_CHECK_H 1

int isword( aut_t *paut, char *str) ;

#endif

